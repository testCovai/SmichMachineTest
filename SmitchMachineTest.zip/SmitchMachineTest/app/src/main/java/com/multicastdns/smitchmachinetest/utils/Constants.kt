package com.multicastdns.smitchmachinetest.utils

/**
 * Created by Nehru DN on 07/07/2020.
 */
object Constants {
    const val SERVICE_TYPE = "_http._tcp."
    const val SERVICE_NAME = "MyService001"
    const val PORT = 80
}